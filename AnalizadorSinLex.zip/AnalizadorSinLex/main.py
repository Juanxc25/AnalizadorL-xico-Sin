from flask import Flask, request, render_template
import os  
import analizador_lexico as lex
import analizador_Sintactico as yacc

app = Flask(__name__)

@app.route('/')
def hello_world():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    uploaded_file = request.files['file']

    if uploaded_file.filename != '':
        
        file_path = os.path.join(os.path.dirname(__file__), uploaded_file.filename)
        uploaded_file.save(file_path)

       
        with open(file_path, 'r') as file:
            code = file.read()

        
        lex.reset_lexer()
        lex.lexer.input(code)

        tokens = []
        while True:
            tok = lex.lexer.token()
            if not tok:
                break
            tokens.append({
                'type': tok.type,
                'value': tok.value,
                'line': tok.lineno,
                'lexpos': tok.lexpos
            })

        debug_messages = []
        try:
            yacc.parser.parse(code, debug=debug_messages)
            resultado_sintactico = {"status": "success", "message": "Análisis sintáctico exitoso"}
        except SyntaxError as e:
            resultado_sintactico = {"status": "error", "message": str(e)}
            debug_messages.append(resultado_sintactico)

        
        return render_template('result.html', code=code, tokens=tokens, resultado_sintactico=resultado_sintactico, debug_messages=debug_messages)

    return render_template('index.html', error="No se seleccionó ningún archivo o el archivo está vacío.")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
